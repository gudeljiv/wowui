local ADDON_NAME = ...

local L = LibStub("AceLocale-3.0"):NewLocale(ADDON_NAME, "esES")

if not L then
    return
end

--[[Translation missing --]]
L["ClassicProfessionFilter"] = "ClassicProfessionFilter"
--[[Translation missing --]]
L["Filter your profession window for specific patterns/recipes"] = "Filter your profession window for specific patterns/recipes"
--[[Translation missing --]]
L["Include materials when searching recipes"] = "Include materials when searching recipes"
--[[Translation missing --]]
L["Search Materials"] = "Search Materials"

