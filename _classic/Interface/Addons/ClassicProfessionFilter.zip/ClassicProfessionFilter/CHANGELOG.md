# Changelog

## [1.0.7] - 2021-06-24
### Added
- Search Materials checkbox
- Leatrix Plus support
