# RestedXP Guides

## [v4.3.19](https://github.com/RestedXP/RXPGuides/tree/v4.3.19) (2022-10-09)
[Full Changelog](https://github.com/RestedXP/RXPGuides/compare/v4.3.18...v4.3.19) [Previous Releases](https://github.com/RestedXP/RXPGuides/releases)

- Add bnet querying on import if not detected (#75)  
    Also replaces poor conditional that would error if either uncached or bnet was offline, so cached value was ignored  